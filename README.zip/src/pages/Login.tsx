import React, { useState, useEffect } from 'react'
import ERPLeftShowcase from '../components/ERPLeftShowcase'
import ERPLoginForm from '../components/ERPLoginForm'
import ERPRegisterForm from '../components/ERPRegisterForm'

const Login: React.FC = () => {
  const [mode, setMode] = useState<'signin'|'signup'>('signin')
  
  useEffect(() => {
    // Listen for email confirmation events from other tabs
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'erp_email_confirmed' && e.newValue) {
        // Email was confirmed in another tab, refresh this page
        window.location.reload()
      }
    }
    
    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [])
  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-light via-white to-neutral-soft flex items-center justify-center p-6">
      <div className="w-full max-w-7xl bg-white rounded-3xl shadow-2xl overflow-hidden">
        <div className="flex min-h-[700px]">
          {/* Left Panel - ERP Dashboard Showcase (55%) */}
          <div className="w-[55%] relative bg-gradient-to-br from-primary-light/10 via-primary-medium/5 to-neutral-light overflow-hidden">
            <ERPLeftShowcase />
          </div>
          
          {/* Right Panel - Login Form (45%) */}
          <div className="w-[45%] bg-white flex items-center justify-center p-12">
            {mode === 'signin' ? (
              <ERPLoginForm onShowSignUp={() => setMode('signup')} />
            ) : (
              <ERPRegisterForm onShowSignIn={() => setMode('signin')} />
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Login
